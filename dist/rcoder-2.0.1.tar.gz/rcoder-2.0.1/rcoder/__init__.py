#!/usr/bin/env python3
"""
Rcoder - 远程代码执行与管理系统
"""

__version__ = "2.0.1"
__author__ = "YuKaiXu"
__author_email__ = "yukaixu@outlook.com"
__description__ = "远程代码执行与管理系统，支持MCP、TLS加密、直连和中转模式"
